<script setup>
</script>

<template>
    <div class="tareasMain">
        <div class="tarea"></div>
        <div class="tarea"></div>
        <div class="tarea"></div>
    </div>
</template>

<style scoped>
    .tareasMain{
        height: calc(100dvh - 56px);

        display: flex;
        justify-content: center;
        flex-direction: column;
        align-items: center;
        vertical-align: middle;
        box-sizing: border-box;
        overflow-y: hidden;
    }

    .tarea{
        outline: 1px solid black;
        width: 200px;
        height: 100px;
        background-color: orange;
    }
</style>