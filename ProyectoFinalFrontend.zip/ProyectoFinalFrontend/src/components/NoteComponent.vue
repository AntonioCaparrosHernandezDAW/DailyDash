<script setup>
const props = defineProps({
    idUser: Number,
    title: String,
    text: String
});
</script>

<template>
    <div class="card">
        <h3>{{ props.title }}</h3>
    </div>
</template>

<style scoped>
h3{
    margin-bottom: 0px;
    vertical-align: middle;
}

.card {
    box-sizing: border-box;
    flex-basis: 25%;
    width: 14dvw;
    height: 10dvh;
    padding: 11% 5%;
    border-radius: 30px;
    text-align: center;
}

@media only screen and (max-width: 992px) {
    .card{
        width: 28dvw;
        height: 13dvh;
    }
}
</style>