<script setup>
    import HeaderComponent from './HeaderComponent.vue';
</script>

<template>
    <HeaderComponent />
    <div id="profileMain">
        <div id="userProfilePicture"></div>
        <div id="userUsername"></div>
        <div id="changePassword"></div>
    </div>
</template>

<style scoped>
    #profileMain{
        width: 100dvw;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    #userProfilePicture{
        outline: 1px solid black;
        width: 100px;
        height: 100px;
    }

    #userUsername{
        outline: 1px solid red;
        width: 200px;
        height: 50px;
    }

    #changePassword{
        outline: 1px solid blue;
        width: 100px;
        height: 50px;
    }
</style>