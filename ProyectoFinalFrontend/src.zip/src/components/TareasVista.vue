<script setup>
import ToDoComponent from './ToDoComponent.vue'

let tareas = [
    {id:1, title:"Comprar leche", fechaInicio:"13-11-2020", fechaFin:"14-07-2021"},
    {id:2, title:"Entrenar", fechaInicio:"23-07-2019", fechaFin:"15-07-2022"},
    {id:3, title:"Ir al médico", fechaInicio:"05-02-2023", fechaFin:"06-02-2023"},
    {id:4, title:"Estudiar para el examen", fechaInicio:"10-03-2024", fechaFin:"15-03-2024"},
    {id:5, title:"Hacer la compra", fechaInicio:"20-04-2024", fechaFin:"21-04-2024"},
    {id:6, title:"Enviar correo electrónico", fechaInicio:"03-05-2024", fechaFin:"03-05-2024"},
    {id:7, title:"Preparar presentación", fechaInicio:"08-05-2024", fechaFin:"10-05-2024"},
    {id:8, title:"Llamar al electricista", fechaInicio:"12-05-2024", fechaFin:"12-05-2024"},
    {id:9, title:"Hacer ejercicio", fechaInicio:"16-05-2024", fechaFin:"16-05-2024"},
    {id:10, title:"Leer un libro", fechaInicio:"20-05-2024", fechaFin:"25-05-2024"},
    {id:15, title:"Hacer la compra", fechaInicio:"20-04-2024", fechaFin:"21-04-2024"},
    {id:16, title:"Enviar correo electrónico", fechaInicio:"03-05-2024", fechaFin:"03-05-2024"},
    {id:17, title:"Preparar presentación", fechaInicio:"08-05-2024", fechaFin:"10-05-2024"},
    {id:18, title:"Llamar al electricista", fechaInicio:"12-05-2024", fechaFin:"12-05-2024"},
    {id:19, title:"Hacer ejercicio", fechaInicio:"16-05-2024", fechaFin:"16-05-2024"},
    {id:20, title:"Leer un libro", fechaInicio:"20-05-2024", fechaFin:"25-05-2024"},
    {id:21, title:"Hacer la compra", fechaInicio:"20-04-2024", fechaFin:"21-04-2024"},
    {id:22, title:"Enviar correo electrónico", fechaInicio:"03-05-2024", fechaFin:"03-05-2024"},
    {id:23, title:"Preparar presentación", fechaInicio:"08-05-2024", fechaFin:"10-05-2024"},
    {id:24, title:"Llamar al electricista", fechaInicio:"12-05-2024", fechaFin:"12-05-2024"},
    {id:25, title:"Hacer ejercicio", fechaInicio:"16-05-2024", fechaFin:"16-05-2024"},
    {id:26, title:"Leer un libro", fechaInicio:"20-05-2024", fechaFin:"25-05-2024"}
];
</script>

<template>
    <div class="tareasMain">
        <table>
            <tr>
                <th>Título</th>
                <th>Prioridad</th>
                <th>FechaInicio</th>
                <th>FechaFin</th>
                <th>Completar</th>
                <th>Editar</th>
                <th>Borrar</th>
            </tr>
            <tr v-for="(tarea, key) in tareas" :key="key">
                <ToDoComponent />
            </tr>
        </table>
    </div>
</template>

<style scoped>
    .tareasMain{
        display: flex;
        justify-content: center;
        flex-direction: column;
        align-items: center;
        vertical-align: middle;
        box-sizing: border-box;
        overflow-y: scroll;
        padding: 5dvh 0px;
    }

    
</style>