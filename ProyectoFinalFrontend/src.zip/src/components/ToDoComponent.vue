<script setup>

</script>

<template>
    <div class="tarea">
        <th>Título</th>
                <th>Prioridad</th>
                <th>FechaInicio</th>
                <th>FechaFin</th>
                <th>Completar</th>
                <th>Editar</th>
                <th>Borrar</th>
    </div>
</template>

<style scoped>
    .tarea{
        outline: 1px solid black;
        width: 200px;
        height: 75px;
        background-color: orange;
    }
</style>